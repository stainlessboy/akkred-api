--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5
-- Dumped by pg_dump version 11.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE akkred;
--
-- Name: akkred; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE akkred WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE akkred OWNER TO postgres;

\connect akkred

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO akkred_user;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO akkred_user;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO akkred_user;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO akkred_user;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO akkred_user;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO akkred_user;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO akkred_user;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO akkred_user;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO akkred_user;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO akkred_user;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO akkred_user;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO akkred_user;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO akkred_user;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO akkred_user;

--
-- Name: easy_thumbnails_source; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.easy_thumbnails_source (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL
);


ALTER TABLE public.easy_thumbnails_source OWNER TO akkred_user;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.easy_thumbnails_source_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_source_id_seq OWNER TO akkred_user;

--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.easy_thumbnails_source_id_seq OWNED BY public.easy_thumbnails_source.id;


--
-- Name: easy_thumbnails_thumbnail; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.easy_thumbnails_thumbnail (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    source_id integer NOT NULL
);


ALTER TABLE public.easy_thumbnails_thumbnail OWNER TO akkred_user;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.easy_thumbnails_thumbnail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnail_id_seq OWNER TO akkred_user;

--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.easy_thumbnails_thumbnail_id_seq OWNED BY public.easy_thumbnails_thumbnail.id;


--
-- Name: easy_thumbnails_thumbnaildimensions; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.easy_thumbnails_thumbnaildimensions (
    id integer NOT NULL,
    thumbnail_id integer NOT NULL,
    width integer,
    height integer,
    CONSTRAINT easy_thumbnails_thumbnaildimensions_height_check CHECK ((height >= 0)),
    CONSTRAINT easy_thumbnails_thumbnaildimensions_width_check CHECK ((width >= 0))
);


ALTER TABLE public.easy_thumbnails_thumbnaildimensions OWNER TO akkred_user;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.easy_thumbnails_thumbnaildimensions_id_seq OWNER TO akkred_user;

--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.easy_thumbnails_thumbnaildimensions_id_seq OWNED BY public.easy_thumbnails_thumbnaildimensions.id;


--
-- Name: main_articles; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_articles (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    image_id integer
);


ALTER TABLE public.main_articles OWNER TO akkred_user;

--
-- Name: main_articles_gallery; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_articles_gallery (
    id integer NOT NULL,
    articles_id integer NOT NULL,
    file_id integer NOT NULL
);


ALTER TABLE public.main_articles_gallery OWNER TO akkred_user;

--
-- Name: main_articles_gallery_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_articles_gallery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_articles_gallery_id_seq OWNER TO akkred_user;

--
-- Name: main_articles_gallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_articles_gallery_id_seq OWNED BY public.main_articles_gallery.id;


--
-- Name: main_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_articles_id_seq OWNER TO akkred_user;

--
-- Name: main_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_articles_id_seq OWNED BY public.main_articles.id;


--
-- Name: main_categoryreestrinfouser; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_categoryreestrinfouser (
    id integer NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.main_categoryreestrinfouser OWNER TO akkred_user;

--
-- Name: main_categoryreestrinfouser_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_categoryreestrinfouser_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_categoryreestrinfouser_id_seq OWNER TO akkred_user;

--
-- Name: main_categoryreestrinfouser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_categoryreestrinfouser_id_seq OWNED BY public.main_categoryreestrinfouser.id;


--
-- Name: main_docparent; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_docparent (
    id integer NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.main_docparent OWNER TO akkred_user;

--
-- Name: main_docparent_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_docparent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_docparent_id_seq OWNER TO akkred_user;

--
-- Name: main_docparent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_docparent_id_seq OWNED BY public.main_docparent.id;


--
-- Name: main_doctype; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_doctype (
    id integer NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.main_doctype OWNER TO akkred_user;

--
-- Name: main_doctype_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_doctype_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_doctype_id_seq OWNER TO akkred_user;

--
-- Name: main_doctype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_doctype_id_seq OWNED BY public.main_doctype.id;


--
-- Name: main_document; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_document (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    file character varying(100),
    parents_id integer NOT NULL,
    type_id integer,
    number character varying(300),
    link character varying(300),
    status character varying(20) NOT NULL
);


ALTER TABLE public.main_document OWNER TO akkred_user;

--
-- Name: main_document_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_document_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_document_id_seq OWNER TO akkred_user;

--
-- Name: main_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_document_id_seq OWNED BY public.main_document.id;


--
-- Name: main_employee; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_employee (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    name_ru character varying(255),
    name_en character varying(255),
    name_uz character varying(255),
    "position" character varying(255) NOT NULL,
    position_ru character varying(255),
    position_en character varying(255),
    position_uz character varying(255),
    description text,
    description_ru text,
    description_en text,
    description_uz text,
    image character varying(100),
    email character varying(255),
    phone character varying(255)
);


ALTER TABLE public.main_employee OWNER TO akkred_user;

--
-- Name: main_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_employee_id_seq OWNER TO akkred_user;

--
-- Name: main_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_employee_id_seq OWNED BY public.main_employee.id;


--
-- Name: main_file; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_file (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    is_delete boolean NOT NULL,
    name character varying(255),
    content_type character varying(255),
    file character varying(100) NOT NULL
);


ALTER TABLE public.main_file OWNER TO akkred_user;

--
-- Name: main_file_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_file_id_seq OWNER TO akkred_user;

--
-- Name: main_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_file_id_seq OWNED BY public.main_file.id;


--
-- Name: main_laws; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_laws (
    id integer NOT NULL,
    name text NOT NULL,
    name_ru text,
    name_en text,
    name_uz text,
    name2 text NOT NULL,
    name2_ru text,
    name2_en text,
    name2_uz text,
    link character varying(300) NOT NULL,
    link_ru character varying(300),
    link_en character varying(300),
    link_uz character varying(300),
    category_id integer NOT NULL
);


ALTER TABLE public.main_laws OWNER TO akkred_user;

--
-- Name: main_laws_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_laws_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_laws_id_seq OWNER TO akkred_user;

--
-- Name: main_laws_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_laws_id_seq OWNED BY public.main_laws.id;


--
-- Name: main_lawscategory; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_lawscategory (
    id integer NOT NULL,
    name character varying(300) NOT NULL
);


ALTER TABLE public.main_lawscategory OWNER TO akkred_user;

--
-- Name: main_lawscategory_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_lawscategory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_lawscategory_id_seq OWNER TO akkred_user;

--
-- Name: main_lawscategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_lawscategory_id_seq OWNED BY public.main_lawscategory.id;


--
-- Name: main_media; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_media (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    title_ru character varying(255),
    title_en character varying(255),
    title_uz character varying(255),
    description text,
    description_ru text,
    description_en text,
    description_uz text,
    image_id integer
);


ALTER TABLE public.main_media OWNER TO akkred_user;

--
-- Name: main_media_gallery; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_media_gallery (
    id integer NOT NULL,
    media_id integer NOT NULL,
    file_id integer NOT NULL
);


ALTER TABLE public.main_media_gallery OWNER TO akkred_user;

--
-- Name: main_media_gallery_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_media_gallery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_media_gallery_id_seq OWNER TO akkred_user;

--
-- Name: main_media_gallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_media_gallery_id_seq OWNED BY public.main_media_gallery.id;


--
-- Name: main_media_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_media_id_seq OWNER TO akkred_user;

--
-- Name: main_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_media_id_seq OWNED BY public.main_media.id;


--
-- Name: main_mediafile; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_mediafile (
    id integer NOT NULL,
    file character varying(100) NOT NULL,
    name character varying(255)
);


ALTER TABLE public.main_mediafile OWNER TO akkred_user;

--
-- Name: main_mediafile_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_mediafile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_mediafile_id_seq OWNER TO akkred_user;

--
-- Name: main_mediafile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_mediafile_id_seq OWNED BY public.main_mediafile.id;


--
-- Name: main_news; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_news (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    title_ru character varying(255),
    title_en character varying(255),
    title_uz character varying(255),
    text text,
    text_ru text,
    text_en text,
    text_uz text,
    image_main character varying(100),
    created_date_by_admin timestamp with time zone
);


ALTER TABLE public.main_news OWNER TO akkred_user;

--
-- Name: main_news_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_news_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_news_id_seq OWNER TO akkred_user;

--
-- Name: main_news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_news_id_seq OWNED BY public.main_news.id;


--
-- Name: main_newsgallery; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_newsgallery (
    id integer NOT NULL,
    image character varying(100),
    news_id integer NOT NULL
);


ALTER TABLE public.main_newsgallery OWNER TO akkred_user;

--
-- Name: main_newsgallery_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_newsgallery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_newsgallery_id_seq OWNER TO akkred_user;

--
-- Name: main_newsgallery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_newsgallery_id_seq OWNED BY public.main_newsgallery.id;


--
-- Name: main_question; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_question (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    question text NOT NULL,
    question_ru text,
    question_en text,
    question_uz text,
    answer text NOT NULL,
    answer_ru text,
    answer_en text,
    answer_uz text
);


ALTER TABLE public.main_question OWNER TO akkred_user;

--
-- Name: main_question_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_question_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_question_id_seq OWNER TO akkred_user;

--
-- Name: main_question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_question_id_seq OWNED BY public.main_question.id;


--
-- Name: main_reestrinfouser; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_reestrinfouser (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    number character varying(255) NOT NULL,
    type_id integer,
    date_active date,
    date_inactive date,
    date_paused date
);


ALTER TABLE public.main_reestrinfouser OWNER TO akkred_user;

--
-- Name: main_reestrinfouser_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_reestrinfouser_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_reestrinfouser_id_seq OWNER TO akkred_user;

--
-- Name: main_reestrinfouser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_reestrinfouser_id_seq OWNED BY public.main_reestrinfouser.id;


--
-- Name: main_region; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_region (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.main_region OWNER TO akkred_user;

--
-- Name: main_region_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_region_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_region_id_seq OWNER TO akkred_user;

--
-- Name: main_region_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_region_id_seq OWNED BY public.main_region.id;


--
-- Name: main_registries; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_registries (
    id integer NOT NULL,
    title_organ character varying(255) NOT NULL,
    number character varying(255),
    code character varying(255),
    status character varying(20) NOT NULL,
    full_name_supervisor_ao character varying(255),
    inn character varying(455),
    phone character varying(255),
    email character varying(255),
    address_organ character varying(1000),
    keywords character varying(255) NOT NULL,
    text text,
    area character varying(255) NOT NULL,
    status_date date,
    accreditation_date date,
    accreditation_duration date,
    region_id integer,
    type_organ_id integer NOT NULL,
    designation_of_the_fundamental_standard character varying(455),
    accreditation_duration_text character varying(1000),
    address_yurd_lisa character varying(1000),
    title_yurd_lisa character varying(1000),
    email_ao character varying(255),
    phone_ao character varying(255),
    web_site character varying(255),
    file_oblast character varying(100),
    is_fact_address boolean NOT NULL
);


ALTER TABLE public.main_registries OWNER TO akkred_user;

--
-- Name: main_registries_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_registries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_registries_id_seq OWNER TO akkred_user;

--
-- Name: main_registries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_registries_id_seq OWNED BY public.main_registries.id;


--
-- Name: main_registriesstatus; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_registriesstatus (
    id integer NOT NULL,
    status character varying(20) NOT NULL,
    date date,
    reestr_id integer NOT NULL
);


ALTER TABLE public.main_registriesstatus OWNER TO akkred_user;

--
-- Name: main_registriesstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_registriesstatus_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_registriesstatus_id_seq OWNER TO akkred_user;

--
-- Name: main_registriesstatus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_registriesstatus_id_seq OWNED BY public.main_registriesstatus.id;


--
-- Name: main_review; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_review (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    author character varying(255) NOT NULL,
    author_ru character varying(255),
    author_en character varying(255),
    author_uz character varying(255),
    "position" character varying(255) NOT NULL,
    description text,
    description_ru text,
    description_en text,
    description_uz text,
    image_id integer NOT NULL
);


ALTER TABLE public.main_review OWNER TO akkred_user;

--
-- Name: main_review_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_review_id_seq OWNER TO akkred_user;

--
-- Name: main_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_review_id_seq OWNED BY public.main_review.id;


--
-- Name: main_slider; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_slider (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    link character varying(255),
    image character varying(100)
);


ALTER TABLE public.main_slider OWNER TO akkred_user;

--
-- Name: main_slider_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_slider_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_slider_id_seq OWNER TO akkred_user;

--
-- Name: main_slider_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_slider_id_seq OWNED BY public.main_slider.id;


--
-- Name: main_staticpage; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_staticpage (
    id integer NOT NULL,
    created_date timestamp with time zone NOT NULL,
    modified_date timestamp with time zone NOT NULL,
    key_name character varying(200) NOT NULL,
    name character varying(255),
    name_ru character varying(255),
    name_en character varying(255),
    name_uz character varying(255),
    body text,
    body_ru text,
    body_en text,
    body_uz text,
    type character varying(255) NOT NULL
);


ALTER TABLE public.main_staticpage OWNER TO akkred_user;

--
-- Name: main_staticpage_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_staticpage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_staticpage_id_seq OWNER TO akkred_user;

--
-- Name: main_staticpage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_staticpage_id_seq OWNED BY public.main_staticpage.id;


--
-- Name: main_typeorgan; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_typeorgan (
    id integer NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE public.main_typeorgan OWNER TO akkred_user;

--
-- Name: main_typeorgan_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_typeorgan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_typeorgan_id_seq OWNER TO akkred_user;

--
-- Name: main_typeorgan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_typeorgan_id_seq OWNED BY public.main_typeorgan.id;


--
-- Name: main_user; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    user_type character varying(20) NOT NULL
);


ALTER TABLE public.main_user OWNER TO akkred_user;

--
-- Name: main_user_groups; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.main_user_groups OWNER TO akkred_user;

--
-- Name: main_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_user_groups_id_seq OWNER TO akkred_user;

--
-- Name: main_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_user_groups_id_seq OWNED BY public.main_user_groups.id;


--
-- Name: main_user_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_user_id_seq OWNER TO akkred_user;

--
-- Name: main_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_user_id_seq OWNED BY public.main_user.id;


--
-- Name: main_user_user_permissions; Type: TABLE; Schema: public; Owner: akkred_user
--

CREATE TABLE public.main_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.main_user_user_permissions OWNER TO akkred_user;

--
-- Name: main_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: akkred_user
--

CREATE SEQUENCE public.main_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.main_user_user_permissions_id_seq OWNER TO akkred_user;

--
-- Name: main_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: akkred_user
--

ALTER SEQUENCE public.main_user_user_permissions_id_seq OWNED BY public.main_user_user_permissions.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: easy_thumbnails_source id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_source ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_source_id_seq'::regclass);


--
-- Name: easy_thumbnails_thumbnail id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_thumbnail_id_seq'::regclass);


--
-- Name: easy_thumbnails_thumbnaildimensions id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions ALTER COLUMN id SET DEFAULT nextval('public.easy_thumbnails_thumbnaildimensions_id_seq'::regclass);


--
-- Name: main_articles id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_articles ALTER COLUMN id SET DEFAULT nextval('public.main_articles_id_seq'::regclass);


--
-- Name: main_articles_gallery id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_articles_gallery ALTER COLUMN id SET DEFAULT nextval('public.main_articles_gallery_id_seq'::regclass);


--
-- Name: main_categoryreestrinfouser id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_categoryreestrinfouser ALTER COLUMN id SET DEFAULT nextval('public.main_categoryreestrinfouser_id_seq'::regclass);


--
-- Name: main_docparent id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_docparent ALTER COLUMN id SET DEFAULT nextval('public.main_docparent_id_seq'::regclass);


--
-- Name: main_doctype id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_doctype ALTER COLUMN id SET DEFAULT nextval('public.main_doctype_id_seq'::regclass);


--
-- Name: main_document id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_document ALTER COLUMN id SET DEFAULT nextval('public.main_document_id_seq'::regclass);


--
-- Name: main_employee id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_employee ALTER COLUMN id SET DEFAULT nextval('public.main_employee_id_seq'::regclass);


--
-- Name: main_file id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_file ALTER COLUMN id SET DEFAULT nextval('public.main_file_id_seq'::regclass);


--
-- Name: main_laws id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_laws ALTER COLUMN id SET DEFAULT nextval('public.main_laws_id_seq'::regclass);


--
-- Name: main_lawscategory id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_lawscategory ALTER COLUMN id SET DEFAULT nextval('public.main_lawscategory_id_seq'::regclass);


--
-- Name: main_media id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_media ALTER COLUMN id SET DEFAULT nextval('public.main_media_id_seq'::regclass);


--
-- Name: main_media_gallery id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_media_gallery ALTER COLUMN id SET DEFAULT nextval('public.main_media_gallery_id_seq'::regclass);


--
-- Name: main_mediafile id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_mediafile ALTER COLUMN id SET DEFAULT nextval('public.main_mediafile_id_seq'::regclass);


--
-- Name: main_news id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_news ALTER COLUMN id SET DEFAULT nextval('public.main_news_id_seq'::regclass);


--
-- Name: main_newsgallery id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_newsgallery ALTER COLUMN id SET DEFAULT nextval('public.main_newsgallery_id_seq'::regclass);


--
-- Name: main_question id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_question ALTER COLUMN id SET DEFAULT nextval('public.main_question_id_seq'::regclass);


--
-- Name: main_reestrinfouser id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_reestrinfouser ALTER COLUMN id SET DEFAULT nextval('public.main_reestrinfouser_id_seq'::regclass);


--
-- Name: main_region id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_region ALTER COLUMN id SET DEFAULT nextval('public.main_region_id_seq'::regclass);


--
-- Name: main_registries id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_registries ALTER COLUMN id SET DEFAULT nextval('public.main_registries_id_seq'::regclass);


--
-- Name: main_registriesstatus id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_registriesstatus ALTER COLUMN id SET DEFAULT nextval('public.main_registriesstatus_id_seq'::regclass);


--
-- Name: main_review id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_review ALTER COLUMN id SET DEFAULT nextval('public.main_review_id_seq'::regclass);


--
-- Name: main_slider id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_slider ALTER COLUMN id SET DEFAULT nextval('public.main_slider_id_seq'::regclass);


--
-- Name: main_staticpage id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_staticpage ALTER COLUMN id SET DEFAULT nextval('public.main_staticpage_id_seq'::regclass);


--
-- Name: main_typeorgan id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_typeorgan ALTER COLUMN id SET DEFAULT nextval('public.main_typeorgan_id_seq'::regclass);


--
-- Name: main_user id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user ALTER COLUMN id SET DEFAULT nextval('public.main_user_id_seq'::regclass);


--
-- Name: main_user_groups id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_groups ALTER COLUMN id SET DEFAULT nextval('public.main_user_groups_id_seq'::regclass);


--
-- Name: main_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.main_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/4126.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/4128.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/4124.dat';

--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.
COPY public.authtoken_token (key, created, user_id) FROM '$$PATH$$/4169.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/4168.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/4122.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/4120.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/4176.dat';

--
-- Data for Name: easy_thumbnails_source; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.easy_thumbnails_source (id, storage_hash, name, modified) FROM stdin;
\.
COPY public.easy_thumbnails_source (id, storage_hash, name, modified) FROM '$$PATH$$/4171.dat';

--
-- Data for Name: easy_thumbnails_thumbnail; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM stdin;
\.
COPY public.easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM '$$PATH$$/4173.dat';

--
-- Data for Name: easy_thumbnails_thumbnaildimensions; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM stdin;
\.
COPY public.easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM '$$PATH$$/4175.dat';

--
-- Data for Name: main_articles; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_articles (id, created_date, modified_date, title, description, image_id) FROM stdin;
\.
COPY public.main_articles (id, created_date, modified_date, title, description, image_id) FROM '$$PATH$$/4136.dat';

--
-- Data for Name: main_articles_gallery; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_articles_gallery (id, articles_id, file_id) FROM stdin;
\.
COPY public.main_articles_gallery (id, articles_id, file_id) FROM '$$PATH$$/4166.dat';

--
-- Data for Name: main_categoryreestrinfouser; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_categoryreestrinfouser (id, title) FROM stdin;
\.
COPY public.main_categoryreestrinfouser (id, title) FROM '$$PATH$$/4178.dat';

--
-- Data for Name: main_docparent; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_docparent (id, title) FROM stdin;
\.
COPY public.main_docparent (id, title) FROM '$$PATH$$/4138.dat';

--
-- Data for Name: main_doctype; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_doctype (id, title) FROM stdin;
\.
COPY public.main_doctype (id, title) FROM '$$PATH$$/4186.dat';

--
-- Data for Name: main_document; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_document (id, created_date, modified_date, title, file, parents_id, type_id, number, link, status) FROM stdin;
\.
COPY public.main_document (id, created_date, modified_date, title, file, parents_id, type_id, number, link, status) FROM '$$PATH$$/4140.dat';

--
-- Data for Name: main_employee; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_employee (id, created_date, modified_date, name, name_ru, name_en, name_uz, "position", position_ru, position_en, position_uz, description, description_ru, description_en, description_uz, image, email, phone) FROM stdin;
\.
COPY public.main_employee (id, created_date, modified_date, name, name_ru, name_en, name_uz, "position", position_ru, position_en, position_uz, description, description_ru, description_en, description_uz, image, email, phone) FROM '$$PATH$$/4142.dat';

--
-- Data for Name: main_file; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_file (id, created_date, modified_date, is_delete, name, content_type, file) FROM stdin;
\.
COPY public.main_file (id, created_date, modified_date, is_delete, name, content_type, file) FROM '$$PATH$$/4144.dat';

--
-- Data for Name: main_laws; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_laws (id, name, name_ru, name_en, name_uz, name2, name2_ru, name2_en, name2_uz, link, link_ru, link_en, link_uz, category_id) FROM stdin;
\.
COPY public.main_laws (id, name, name_ru, name_en, name_uz, name2, name2_ru, name2_en, name2_uz, link, link_ru, link_en, link_uz, category_id) FROM '$$PATH$$/4182.dat';

--
-- Data for Name: main_lawscategory; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_lawscategory (id, name) FROM stdin;
\.
COPY public.main_lawscategory (id, name) FROM '$$PATH$$/4184.dat';

--
-- Data for Name: main_media; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_media (id, created_date, modified_date, title, title_ru, title_en, title_uz, description, description_ru, description_en, description_uz, image_id) FROM stdin;
\.
COPY public.main_media (id, created_date, modified_date, title, title_ru, title_en, title_uz, description, description_ru, description_en, description_uz, image_id) FROM '$$PATH$$/4146.dat';

--
-- Data for Name: main_media_gallery; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_media_gallery (id, media_id, file_id) FROM stdin;
\.
COPY public.main_media_gallery (id, media_id, file_id) FROM '$$PATH$$/4148.dat';

--
-- Data for Name: main_mediafile; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_mediafile (id, file, name) FROM stdin;
\.
COPY public.main_mediafile (id, file, name) FROM '$$PATH$$/4192.dat';

--
-- Data for Name: main_news; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_news (id, created_date, modified_date, title, title_ru, title_en, title_uz, text, text_ru, text_en, text_uz, image_main, created_date_by_admin) FROM stdin;
\.
COPY public.main_news (id, created_date, modified_date, title, title_ru, title_en, title_uz, text, text_ru, text_en, text_uz, image_main, created_date_by_admin) FROM '$$PATH$$/4150.dat';

--
-- Data for Name: main_newsgallery; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_newsgallery (id, image, news_id) FROM stdin;
\.
COPY public.main_newsgallery (id, image, news_id) FROM '$$PATH$$/4190.dat';

--
-- Data for Name: main_question; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_question (id, created_date, modified_date, question, question_ru, question_en, question_uz, answer, answer_ru, answer_en, answer_uz) FROM stdin;
\.
COPY public.main_question (id, created_date, modified_date, question, question_ru, question_en, question_uz, answer, answer_ru, answer_en, answer_uz) FROM '$$PATH$$/4152.dat';

--
-- Data for Name: main_reestrinfouser; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_reestrinfouser (id, created_date, modified_date, title, number, type_id, date_active, date_inactive, date_paused) FROM stdin;
\.
COPY public.main_reestrinfouser (id, created_date, modified_date, title, number, type_id, date_active, date_inactive, date_paused) FROM '$$PATH$$/4180.dat';

--
-- Data for Name: main_region; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_region (id, created_date, modified_date, title) FROM stdin;
\.
COPY public.main_region (id, created_date, modified_date, title) FROM '$$PATH$$/4154.dat';

--
-- Data for Name: main_registries; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_registries (id, title_organ, number, code, status, full_name_supervisor_ao, inn, phone, email, address_organ, keywords, text, area, status_date, accreditation_date, accreditation_duration, region_id, type_organ_id, designation_of_the_fundamental_standard, accreditation_duration_text, address_yurd_lisa, title_yurd_lisa, email_ao, phone_ao, web_site, file_oblast, is_fact_address) FROM stdin;
\.
COPY public.main_registries (id, title_organ, number, code, status, full_name_supervisor_ao, inn, phone, email, address_organ, keywords, text, area, status_date, accreditation_date, accreditation_duration, region_id, type_organ_id, designation_of_the_fundamental_standard, accreditation_duration_text, address_yurd_lisa, title_yurd_lisa, email_ao, phone_ao, web_site, file_oblast, is_fact_address) FROM '$$PATH$$/4156.dat';

--
-- Data for Name: main_registriesstatus; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_registriesstatus (id, status, date, reestr_id) FROM stdin;
\.
COPY public.main_registriesstatus (id, status, date, reestr_id) FROM '$$PATH$$/4188.dat';

--
-- Data for Name: main_review; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_review (id, created_date, modified_date, author, author_ru, author_en, author_uz, "position", description, description_ru, description_en, description_uz, image_id) FROM stdin;
\.
COPY public.main_review (id, created_date, modified_date, author, author_ru, author_en, author_uz, "position", description, description_ru, description_en, description_uz, image_id) FROM '$$PATH$$/4158.dat';

--
-- Data for Name: main_slider; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_slider (id, created_date, modified_date, title, description, link, image) FROM stdin;
\.
COPY public.main_slider (id, created_date, modified_date, title, description, link, image) FROM '$$PATH$$/4160.dat';

--
-- Data for Name: main_staticpage; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_staticpage (id, created_date, modified_date, key_name, name, name_ru, name_en, name_uz, body, body_ru, body_en, body_uz, type) FROM stdin;
\.
COPY public.main_staticpage (id, created_date, modified_date, key_name, name, name_ru, name_en, name_uz, body, body_ru, body_en, body_uz, type) FROM '$$PATH$$/4162.dat';

--
-- Data for Name: main_typeorgan; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_typeorgan (id, title) FROM stdin;
\.
COPY public.main_typeorgan (id, title) FROM '$$PATH$$/4164.dat';

--
-- Data for Name: main_user; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_user (id, password, last_login, is_superuser, username, email, is_staff, is_active, date_joined, user_type) FROM stdin;
\.
COPY public.main_user (id, password, last_login, is_superuser, username, email, is_staff, is_active, date_joined, user_type) FROM '$$PATH$$/4130.dat';

--
-- Data for Name: main_user_groups; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.main_user_groups (id, user_id, group_id) FROM '$$PATH$$/4132.dat';

--
-- Data for Name: main_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: akkred_user
--

COPY public.main_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.main_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/4134.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 128, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1281, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 32, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 53, true);


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.easy_thumbnails_source_id_seq', 1, false);


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnail_id_seq', 1, false);


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnaildimensions_id_seq', 1, false);


--
-- Name: main_articles_gallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_articles_gallery_id_seq', 1, false);


--
-- Name: main_articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_articles_id_seq', 1, false);


--
-- Name: main_categoryreestrinfouser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_categoryreestrinfouser_id_seq', 2, true);


--
-- Name: main_docparent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_docparent_id_seq', 3, true);


--
-- Name: main_doctype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_doctype_id_seq', 10, true);


--
-- Name: main_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_document_id_seq', 71, true);


--
-- Name: main_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_employee_id_seq', 13, true);


--
-- Name: main_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_file_id_seq', 10, true);


--
-- Name: main_laws_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_laws_id_seq', 11, true);


--
-- Name: main_lawscategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_lawscategory_id_seq', 3, true);


--
-- Name: main_media_gallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_media_gallery_id_seq', 1, false);


--
-- Name: main_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_media_id_seq', 1, false);


--
-- Name: main_mediafile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_mediafile_id_seq', 1, true);


--
-- Name: main_news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_news_id_seq', 10, true);


--
-- Name: main_newsgallery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_newsgallery_id_seq', 1, true);


--
-- Name: main_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_question_id_seq', 5, true);


--
-- Name: main_reestrinfouser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_reestrinfouser_id_seq', 2, true);


--
-- Name: main_region_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_region_id_seq', 15, true);


--
-- Name: main_registries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_registries_id_seq', 946, true);


--
-- Name: main_registriesstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_registriesstatus_id_seq', 3, true);


--
-- Name: main_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_review_id_seq', 1, false);


--
-- Name: main_slider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_slider_id_seq', 3, true);


--
-- Name: main_staticpage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_staticpage_id_seq', 16, true);


--
-- Name: main_typeorgan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_typeorgan_id_seq', 9, true);


--
-- Name: main_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_user_groups_id_seq', 1, false);


--
-- Name: main_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_user_id_seq', 1, true);


--
-- Name: main_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: akkred_user
--

SELECT pg_catalog.setval('public.main_user_user_permissions_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_storage_hash_name_481ce32d_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_storage_hash_name_481ce32d_uniq UNIQUE (storage_hash, name);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq UNIQUE (storage_hash, name, source_id);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_thumbnail_id_key; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key UNIQUE (thumbnail_id);


--
-- Name: main_articles_gallery main_articles_gallery_articles_id_file_id_b9b18325_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_articles_gallery
    ADD CONSTRAINT main_articles_gallery_articles_id_file_id_b9b18325_uniq UNIQUE (articles_id, file_id);


--
-- Name: main_articles_gallery main_articles_gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_articles_gallery
    ADD CONSTRAINT main_articles_gallery_pkey PRIMARY KEY (id);


--
-- Name: main_articles main_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_articles
    ADD CONSTRAINT main_articles_pkey PRIMARY KEY (id);


--
-- Name: main_categoryreestrinfouser main_categoryreestrinfouser_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_categoryreestrinfouser
    ADD CONSTRAINT main_categoryreestrinfouser_pkey PRIMARY KEY (id);


--
-- Name: main_docparent main_docparent_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_docparent
    ADD CONSTRAINT main_docparent_pkey PRIMARY KEY (id);


--
-- Name: main_doctype main_doctype_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_doctype
    ADD CONSTRAINT main_doctype_pkey PRIMARY KEY (id);


--
-- Name: main_document main_document_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_document
    ADD CONSTRAINT main_document_pkey PRIMARY KEY (id);


--
-- Name: main_employee main_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_employee
    ADD CONSTRAINT main_employee_pkey PRIMARY KEY (id);


--
-- Name: main_file main_file_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_file
    ADD CONSTRAINT main_file_pkey PRIMARY KEY (id);


--
-- Name: main_laws main_laws_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_laws
    ADD CONSTRAINT main_laws_pkey PRIMARY KEY (id);


--
-- Name: main_lawscategory main_lawscategory_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_lawscategory
    ADD CONSTRAINT main_lawscategory_pkey PRIMARY KEY (id);


--
-- Name: main_media_gallery main_media_gallery_media_id_file_id_289b6c46_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_media_gallery
    ADD CONSTRAINT main_media_gallery_media_id_file_id_289b6c46_uniq UNIQUE (media_id, file_id);


--
-- Name: main_media_gallery main_media_gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_media_gallery
    ADD CONSTRAINT main_media_gallery_pkey PRIMARY KEY (id);


--
-- Name: main_media main_media_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_media
    ADD CONSTRAINT main_media_pkey PRIMARY KEY (id);


--
-- Name: main_mediafile main_mediafile_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_mediafile
    ADD CONSTRAINT main_mediafile_pkey PRIMARY KEY (id);


--
-- Name: main_news main_news_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_news
    ADD CONSTRAINT main_news_pkey PRIMARY KEY (id);


--
-- Name: main_newsgallery main_newsgallery_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_newsgallery
    ADD CONSTRAINT main_newsgallery_pkey PRIMARY KEY (id);


--
-- Name: main_question main_question_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_question
    ADD CONSTRAINT main_question_pkey PRIMARY KEY (id);


--
-- Name: main_reestrinfouser main_reestrinfouser_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_reestrinfouser
    ADD CONSTRAINT main_reestrinfouser_pkey PRIMARY KEY (id);


--
-- Name: main_region main_region_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_region
    ADD CONSTRAINT main_region_pkey PRIMARY KEY (id);


--
-- Name: main_registries main_registries_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_registries
    ADD CONSTRAINT main_registries_pkey PRIMARY KEY (id);


--
-- Name: main_registriesstatus main_registriesstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_registriesstatus
    ADD CONSTRAINT main_registriesstatus_pkey PRIMARY KEY (id);


--
-- Name: main_review main_review_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_review
    ADD CONSTRAINT main_review_pkey PRIMARY KEY (id);


--
-- Name: main_slider main_slider_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_slider
    ADD CONSTRAINT main_slider_pkey PRIMARY KEY (id);


--
-- Name: main_staticpage main_staticpage_key_name_key; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_staticpage
    ADD CONSTRAINT main_staticpage_key_name_key UNIQUE (key_name);


--
-- Name: main_staticpage main_staticpage_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_staticpage
    ADD CONSTRAINT main_staticpage_pkey PRIMARY KEY (id);


--
-- Name: main_typeorgan main_typeorgan_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_typeorgan
    ADD CONSTRAINT main_typeorgan_pkey PRIMARY KEY (id);


--
-- Name: main_user_groups main_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_groups
    ADD CONSTRAINT main_user_groups_pkey PRIMARY KEY (id);


--
-- Name: main_user_groups main_user_groups_user_id_group_id_ae195797_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_groups
    ADD CONSTRAINT main_user_groups_user_id_group_id_ae195797_uniq UNIQUE (user_id, group_id);


--
-- Name: main_user main_user_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user
    ADD CONSTRAINT main_user_pkey PRIMARY KEY (id);


--
-- Name: main_user_user_permissions main_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_user_permissions
    ADD CONSTRAINT main_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: main_user_user_permissions main_user_user_permissions_user_id_permission_id_96b9fadf_uniq; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_user_permissions
    ADD CONSTRAINT main_user_user_permissions_user_id_permission_id_96b9fadf_uniq UNIQUE (user_id, permission_id);


--
-- Name: main_user main_user_username_key; Type: CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user
    ADD CONSTRAINT main_user_username_key UNIQUE (username);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_name_5fe0edc6; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6 ON public.easy_thumbnails_source USING btree (name);


--
-- Name: easy_thumbnails_source_name_5fe0edc6_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6_like ON public.easy_thumbnails_source USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9 ON public.easy_thumbnails_source USING btree (storage_hash);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9_like ON public.easy_thumbnails_source USING btree (storage_hash varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31 ON public.easy_thumbnails_thumbnail USING btree (name);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31_like ON public.easy_thumbnails_thumbnail USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_source_id_5b57bc77; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_thumbnail_source_id_5b57bc77 ON public.easy_thumbnails_thumbnail USING btree (source_id);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49 ON public.easy_thumbnails_thumbnail USING btree (storage_hash);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49_like ON public.easy_thumbnails_thumbnail USING btree (storage_hash varchar_pattern_ops);


--
-- Name: main_articles_gallery_articles_id_7173c38a; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_articles_gallery_articles_id_7173c38a ON public.main_articles_gallery USING btree (articles_id);


--
-- Name: main_articles_gallery_file_id_76daf507; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_articles_gallery_file_id_76daf507 ON public.main_articles_gallery USING btree (file_id);


--
-- Name: main_articles_image_id_60d9c1ac; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_articles_image_id_60d9c1ac ON public.main_articles USING btree (image_id);


--
-- Name: main_document_parents_id_3bccf93a; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_document_parents_id_3bccf93a ON public.main_document USING btree (parents_id);


--
-- Name: main_document_type_id_d0d0d6d8; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_document_type_id_d0d0d6d8 ON public.main_document USING btree (type_id);


--
-- Name: main_laws_category_id_c05ac579; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_laws_category_id_c05ac579 ON public.main_laws USING btree (category_id);


--
-- Name: main_media_gallery_file_id_bfd21040; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_media_gallery_file_id_bfd21040 ON public.main_media_gallery USING btree (file_id);


--
-- Name: main_media_gallery_media_id_4d9d72fd; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_media_gallery_media_id_4d9d72fd ON public.main_media_gallery USING btree (media_id);


--
-- Name: main_media_image_id_872fd017; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_media_image_id_872fd017 ON public.main_media USING btree (image_id);


--
-- Name: main_newsgallery_news_id_1d8811f1; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_newsgallery_news_id_1d8811f1 ON public.main_newsgallery USING btree (news_id);


--
-- Name: main_reestrinfouser_type_id_54a90089; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_reestrinfouser_type_id_54a90089 ON public.main_reestrinfouser USING btree (type_id);


--
-- Name: main_registries_region_id_30ff7230; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_registries_region_id_30ff7230 ON public.main_registries USING btree (region_id);


--
-- Name: main_registries_type_organ_id_c41c4ec4; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_registries_type_organ_id_c41c4ec4 ON public.main_registries USING btree (type_organ_id);


--
-- Name: main_registriesstatus_reestr_id_1b4349cf; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_registriesstatus_reestr_id_1b4349cf ON public.main_registriesstatus USING btree (reestr_id);


--
-- Name: main_review_image_id_b1f255e3; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_review_image_id_b1f255e3 ON public.main_review USING btree (image_id);


--
-- Name: main_staticpage_key_name_aa241c1b_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_staticpage_key_name_aa241c1b_like ON public.main_staticpage USING btree (key_name varchar_pattern_ops);


--
-- Name: main_user_groups_group_id_a337ba62; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_user_groups_group_id_a337ba62 ON public.main_user_groups USING btree (group_id);


--
-- Name: main_user_groups_user_id_df502602; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_user_groups_user_id_df502602 ON public.main_user_groups USING btree (user_id);


--
-- Name: main_user_user_permissions_permission_id_cd2b56a3; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_user_user_permissions_permission_id_cd2b56a3 ON public.main_user_user_permissions USING btree (permission_id);


--
-- Name: main_user_user_permissions_user_id_451ce57f; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_user_user_permissions_user_id_451ce57f ON public.main_user_user_permissions USING btree (user_id);


--
-- Name: main_user_username_6330637b_like; Type: INDEX; Schema: public; Owner: akkred_user
--

CREATE INDEX main_user_username_6330637b_like ON public.main_user USING btree (username varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_main_user_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_main_user_id FOREIGN KEY (user_id) REFERENCES public.main_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_main_user_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_main_user_id FOREIGN KEY (user_id) REFERENCES public.main_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum FOREIGN KEY (source_id) REFERENCES public.easy_thumbnails_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum FOREIGN KEY (thumbnail_id) REFERENCES public.easy_thumbnails_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_articles_gallery main_articles_gallery_articles_id_7173c38a_fk_main_articles_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_articles_gallery
    ADD CONSTRAINT main_articles_gallery_articles_id_7173c38a_fk_main_articles_id FOREIGN KEY (articles_id) REFERENCES public.main_articles(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_articles_gallery main_articles_gallery_file_id_76daf507_fk_main_file_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_articles_gallery
    ADD CONSTRAINT main_articles_gallery_file_id_76daf507_fk_main_file_id FOREIGN KEY (file_id) REFERENCES public.main_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_articles main_articles_image_id_60d9c1ac_fk_main_file_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_articles
    ADD CONSTRAINT main_articles_image_id_60d9c1ac_fk_main_file_id FOREIGN KEY (image_id) REFERENCES public.main_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_document main_document_parents_id_3bccf93a_fk_main_docparent_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_document
    ADD CONSTRAINT main_document_parents_id_3bccf93a_fk_main_docparent_id FOREIGN KEY (parents_id) REFERENCES public.main_docparent(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_document main_document_type_id_d0d0d6d8_fk_main_doctype_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_document
    ADD CONSTRAINT main_document_type_id_d0d0d6d8_fk_main_doctype_id FOREIGN KEY (type_id) REFERENCES public.main_doctype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_laws main_laws_category_id_c05ac579_fk_main_lawscategory_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_laws
    ADD CONSTRAINT main_laws_category_id_c05ac579_fk_main_lawscategory_id FOREIGN KEY (category_id) REFERENCES public.main_lawscategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_media_gallery main_media_gallery_file_id_bfd21040_fk_main_file_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_media_gallery
    ADD CONSTRAINT main_media_gallery_file_id_bfd21040_fk_main_file_id FOREIGN KEY (file_id) REFERENCES public.main_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_media_gallery main_media_gallery_media_id_4d9d72fd_fk_main_media_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_media_gallery
    ADD CONSTRAINT main_media_gallery_media_id_4d9d72fd_fk_main_media_id FOREIGN KEY (media_id) REFERENCES public.main_media(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_media main_media_image_id_872fd017_fk_main_file_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_media
    ADD CONSTRAINT main_media_image_id_872fd017_fk_main_file_id FOREIGN KEY (image_id) REFERENCES public.main_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_newsgallery main_newsgallery_news_id_1d8811f1_fk_main_news_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_newsgallery
    ADD CONSTRAINT main_newsgallery_news_id_1d8811f1_fk_main_news_id FOREIGN KEY (news_id) REFERENCES public.main_news(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_reestrinfouser main_reestrinfouser_type_id_54a90089_fk_main_cate; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_reestrinfouser
    ADD CONSTRAINT main_reestrinfouser_type_id_54a90089_fk_main_cate FOREIGN KEY (type_id) REFERENCES public.main_categoryreestrinfouser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_registries main_registries_region_id_30ff7230_fk_main_region_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_registries
    ADD CONSTRAINT main_registries_region_id_30ff7230_fk_main_region_id FOREIGN KEY (region_id) REFERENCES public.main_region(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_registries main_registries_type_organ_id_c41c4ec4_fk_main_typeorgan_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_registries
    ADD CONSTRAINT main_registries_type_organ_id_c41c4ec4_fk_main_typeorgan_id FOREIGN KEY (type_organ_id) REFERENCES public.main_typeorgan(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_registriesstatus main_registriesstatus_reestr_id_1b4349cf_fk_main_registries_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_registriesstatus
    ADD CONSTRAINT main_registriesstatus_reestr_id_1b4349cf_fk_main_registries_id FOREIGN KEY (reestr_id) REFERENCES public.main_registries(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_review main_review_image_id_b1f255e3_fk_main_file_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_review
    ADD CONSTRAINT main_review_image_id_b1f255e3_fk_main_file_id FOREIGN KEY (image_id) REFERENCES public.main_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_user_groups main_user_groups_group_id_a337ba62_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_groups
    ADD CONSTRAINT main_user_groups_group_id_a337ba62_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_user_groups main_user_groups_user_id_df502602_fk_main_user_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_groups
    ADD CONSTRAINT main_user_groups_user_id_df502602_fk_main_user_id FOREIGN KEY (user_id) REFERENCES public.main_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_user_user_permissions main_user_user_permi_permission_id_cd2b56a3_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_user_permissions
    ADD CONSTRAINT main_user_user_permi_permission_id_cd2b56a3_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: main_user_user_permissions main_user_user_permissions_user_id_451ce57f_fk_main_user_id; Type: FK CONSTRAINT; Schema: public; Owner: akkred_user
--

ALTER TABLE ONLY public.main_user_user_permissions
    ADD CONSTRAINT main_user_user_permissions_user_id_451ce57f_fk_main_user_id FOREIGN KEY (user_id) REFERENCES public.main_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: DATABASE akkred; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE akkred TO akkred_user;


--
-- PostgreSQL database dump complete
--

